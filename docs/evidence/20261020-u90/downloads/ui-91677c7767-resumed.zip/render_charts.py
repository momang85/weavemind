# -*- coding: utf-8 -*-
"""确定性渲染：读取 chart_data.json（{"charts": [规格]}），按 5 类图表规范绘制。
语义（问题/结论/口径）由 LLM 负责；数字、标注、视觉编码由本脚本保证。
无效规格跳过并打印原因；有效图输出 chart_N.png 并写 chart_manifest.json。"""
import json
import os
import re
import sys

sys.path.insert(0, r"C:\Users\ding0\Desktop\ai_agent\织光")
from chart_specs import COLOR_BLIND_PALETTE, validate_spec, wrap_rows_to_specs

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from chart_fonts import configure_zh_font
configure_zh_font()

CURATED = (
    "规模", "趋势", "份额", "占比", "营收", "收入", "增速", "增长",
    "成本", "价格", "预测", "玩家", "厂商", "格局", "对比", "分布",
    "技术", "市场", "出货", "渗透", "渗透率", "出货量",
    # A3：排行/行情类指标补入，chart_1 的"成交额TOP10"此前关键词为空
    # → 内联匹配失败落入附录堆（好图反而没进正文）
    "成交额", "成交量", "涨跌", "涨幅", "跌幅", "量价", "股价",
    "活跃", "换手", "排行", "TOP10", "排名",
)

def norm(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def is_natural_order(rows):
    """类别标签全是期间/序号（"2023年"、"2024"）→ 保持给定顺序，不按值降序。

    实机反例：只认纯数字时"2023年"匹配不上 → 比率分面图两期被排成"2024年/2023年"，
    颜色与年份的对应也跟着反了。判定复用 `chart_specs.is_period_labels`（唯一实现）。
    """
    from chart_specs import is_period_labels
    return is_period_labels([r.get("label") for r in rows])


def series_key(r, i):
    # 序列名优先取"指标/系列"字段：财务行把整串 label（"2024年营收"）写进 caliber 时，
    # 每行会自成一条单点序列，折线退化成孤立圆点（实机 chart_1 就是 16 个点）。
    return str(r.get("series") or r.get("metric") or r.get("caliber")
               or r.get("source") or f"系列{i + 1}")[:20]


_RANK_PREFIX_RE = re.compile(r"^\d{1,3}\s*[.、．)）]")
_METRIC_SUFFIXES = (
    "最新价", "涨跌幅", "成交额", "成交量", "换手率", "收盘价", "开盘价",
    "最高价", "最低价", "昨收价", "成交金额", "价格", "金额", "涨幅", "跌幅",
)
_NOISE_TAIL_RE = re.compile(r"(画|图|表)$")
_FILLER_RE = re.compile(r"^[的一是在有与和及其了着]{2,}$")


def short_label(r):
    """类别标签清洗（BUG-12）：剥离 "12.股票名最新价" 式数字序号与指标后缀；
    噪声碎片（尾字为 画/图/表 或纯虚词）返回 "?" 供渲染端剔除。
    LLM 有时把指标描述/整句当作 label，优先取 label 首个短片段（长标签**截断**，
    不退化成年份口径——否则类别轴会混进"2024年"）。"""
    label = str(r.get("label") or "").strip() or "?"
    # 数字序号前缀："12.寒武纪最新价" → "寒武纪最新价"
    label = _RANK_PREFIX_RE.sub("", label)
    # 指标后缀："寒武纪最新价" → "寒武纪"（后缀不在开头才剥，避免误伤"涨幅榜"类词）
    for sfx in _METRIC_SUFFIXES:
        if label.endswith(sfx) and label != sfx:
            label = label[: -len(sfx)].strip()
            break
    if len(label) > 12:
        for cand in (label, str(r.get("caliber") or "").strip()):
            for sep in ("，", ",", "；", ";", "：", ":", "（", "("):
                head = cand.split(sep)[0].strip()
                if head and len(head) <= 12:
                    return head
            if len(cand) <= 12 and cand:
                return cand
        src = str(r.get("source") or "")
        m = re.search(r"https?://([^/]+)", src)
        if m:
            return m.group(1).replace("www.", "")[:12]
        return label[:12]
    if (
        not label or label == "?"
        or _NOISE_TAIL_RE.search(label)
        or _FILLER_RE.match(label)
    ):
        return "?"
    return label


def footer_lines(spec, rows, conclusion):
    """图页脚：**只留读数、单位/期间、简短来源与关键假设**（V0，阶段V）。

    为什么改：读图是为了做判断；此前页脚把地域/样本量/缺失/异常/长来源与运行标识
    全画上去，密集工程信息占了阅读空间。工程标识不丢——它在正文『附：底稿索引』
    与包内 analysis/ 里。
    """
    source = str(spec.get("source") or "").strip()
    if not source:
        srcs = [str(r.get("source") or "") for r in rows if r.get("source")]
        source = "；".join(dict.fromkeys(srcs))
    tr = str(spec.get("time_range") or "时间未标注")
    unit = str(spec.get("unit") or "")
    note = str(spec.get("annotation") or "").strip()
    dim = str(spec.get("region") or "").strip()
    lines = []
    if conclusion:
        lines.append("结论：" + conclusion[:140])
    lines.append(f"单位：{unit or '未标注'}　期间：{tr}"
                 + (f"　范围：{dim}" if dim else ""))
    lines.append("来源：" + (source or "未标注")[:90])
    if note:
        lines.append("假设/口径：" + note[:110])
    lines.append("数据未经审计，仅供参考；不同口径数据未合并。")
    return "\n".join(lines)


def add_footer(fig, spec, rows, conclusion):
    fig.text(0.01, 0.004, footer_lines(spec, rows, conclusion),
             fontsize=7.5, color="#444444", va="bottom", ha="left",
             wrap=True)


def keywords_for(spec):
    text = " ".join(str(spec.get(k) or "") for k in ("title", "question", "conclusion"))
    kw = [k for k in CURATED if k in text]
    # 2-gram 滑动切片已移除（曾产生 "年全/片市/场规" 式碎片关键词）
    return list(dict.fromkeys(kw))[:14]


def render_bar(ax, spec, rows, horizontal):
    items = [(short_label(r), norm(r.get("value"))) for r in rows]
    items = [(l, v) for l, v in items if v is not None and l != "?"]
    if not items:
        print(f"SKIP bar: 全部行标签为噪声碎片，无有效数据点", flush=True)
        return False
    if not is_natural_order(rows):
        items.sort(key=lambda t: t[1], reverse=True)
    labels = [l for l, _ in items]
    vals = [v for _, v in items]
    colors = [COLOR_BLIND_PALETTE[i % len(COLOR_BLIND_PALETTE)] for i in range(len(labels))]
    if horizontal:
        ax.barh(labels, vals, color=colors, edgecolor="white")
        if any(v > 0 for v in vals):
            ax.set_xlim(left=0)
    else:
        ax.bar(labels, vals, color=colors, edgecolor="white")
        # 基线只在**有正数**时钉在 0：全是负值（同比下滑/亏损）时 set_ylim(bottom=0)
        # 会让上下限相等、坐标变换退化成奇异值（matplotlib 只发一条 warning 就"自动
        # 扩展"），放在原始数据位置的数值标签随之被甩到画布外几万像素，
        # bbox_inches="tight" 把 PNG 撑成 1038×121366 的空白巨图——报告里既看不见、
        # 导出还照样"成功"（实测场景 chart_2）。负值图改为自动缩放 + 零基线参考线。
        if any(v > 0 for v in vals):
            ax.set_ylim(bottom=0)
        else:
            ax.axhline(0, color="#888888", linewidth=0.8)
    ax.set_xlabel(str(spec.get("x_axis_title") or "类别"))
    ax.set_ylabel(str(spec.get("y_axis_title") or "数值"))
    top5 = set(sorted(vals, reverse=True)[:5]) if len(vals) > 12 else set()
    for i, v in enumerate(vals):
        if len(vals) <= 12 or v in top5:
            if horizontal:
                ax.text(v, i, f"{v:g}", va="center",
                        ha="left" if v >= 0 else "right", fontsize=8)
            else:
                ax.text(i, v, f"{v:g}", ha="center",
                        va="bottom" if v >= 0 else "top", fontsize=8)
    ax.tick_params(axis="x", rotation=28 if (not horizontal and (len(labels) > 4 or max(len(l) for l in labels) > 6)) else 0)
    return True


def render_grouped_bar(ax, spec, rows):
    """分组柱状图：x=类别（指标），series=caliber（年度）——两期对比的标准画法。

    为什么需要它：单序列 bar 只能画一组值，把两年/多个指标塞进去就退化成"16 个科目
    同轴排序"（实机 chart_1 的问题）；分组柱让"每个指标两年并排"一眼可读。
    """
    def _series(r):
        return str(r.get("caliber") or r.get("year") or "系列")[:16]

    groups = []
    series = []
    for r in rows:
        g = short_label(r)
        s = _series(r)
        if g not in groups:
            groups.append(g)
        if s not in series:
            series.append(s)
    if len(groups) < 2 or len(series) < 2:
        return False
    width = 0.8 / len(series)
    xs = np.arange(len(groups))
    plotted = 0
    for si, s in enumerate(series):
        vals = []
        for g in groups:
            v = None
            for r in rows:
                if short_label(r) == g and _series(r) == s:
                    v = norm(r.get("value"))
                    break
            vals.append(v)
        if all(v is None for v in vals):
            continue
        offs = xs + (si - (len(series) - 1) / 2.0) * width
        ax.bar(offs, [0 if v is None else v for v in vals], width,
               color=COLOR_BLIND_PALETTE[si % len(COLOR_BLIND_PALETTE)],
               edgecolor="white", label=s)
        for x, v in zip(offs, vals):
            if v is None:
                continue
            ax.text(x, v, f"{v:g}", ha="center", va="bottom", fontsize=7.5)
        plotted += 1
    if plotted < 2:
        return False
    ax.set_xticks(xs)
    ax.set_xticklabels(groups, rotation=0, fontsize=9)
    ax.legend(fontsize=8, frameon=False)
    # 同 render_bar：全是负值时不得把下限钉在 0（上下限相等 → 坐标变换奇异 →
    # 标签被甩到画布外，tight bbox 撑出空白巨图）
    if any(v is not None and v > 0 for v in
           [norm(r.get("value")) for r in rows]):
        ax.set_ylim(bottom=0)
    else:
        ax.axhline(0, color="#888888", linewidth=0.8)
    ax.set_xlabel(str(spec.get("x_axis_title") or "类别"))
    ax.set_ylabel(str(spec.get("y_axis_title") or "数值"))
    return True


def render_waterfall(ax, spec, rows):
    """可闭合的加总贡献桥（瀑布）：起点/终点柱从 0 起，贡献柱从上一累计起。

    为什么单列一类：桥图的分项是**有符号贡献**，柱状图把每根都从 0 起画会
    看不出"从哪里涨跌到哪里"；只有声明为可闭合桥（structure=bridge）的输出才应当
    画成瀑布，并列情景/敏感度走 grouped_bar / bar。
    """
    items = [(short_label(r), norm(r.get("value")), str(r.get("kind") or "delta"))
             for r in rows]
    items = [(l, v, k) for l, v, k in items if v is not None and l != "?"]
    if len(items) < 3:
        print("SKIP waterfall: 可闭合桥至少要有起点/贡献/终点三根柱子", flush=True)
        return False
    labels = [l for l, _, _ in items]
    vals = [v for _, v, _ in items]
    kinds = [k for _, _, k in items]
    POS, NEG, TOT = "#0072B2", "#D55E00", "#333333"
    starts, run = [], 0.0
    for v, k in zip(vals, kinds):
        if k in ("base", "total"):
            starts.append(0.0)
            run = v
        else:
            starts.append(run)
            run += v
    for i, (s, v, k) in enumerate(zip(starts, vals, kinds)):
        color = TOT if k in ("base", "total") else (POS if v >= 0 else NEG)
        ax.bar(i, abs(v), bottom=min(s, s + v), color=color, edgecolor="white")
        ax.text(i, s + v, f"{v:+g}" if k not in ("base", "total") else f"{v:g}",
                ha="center", va="bottom" if v >= 0 else "top", fontsize=8)
        if i + 1 < len(labels):
            ax.plot([i, i + 1], [s + v, s + v], color="#999999", linewidth=0.8,
                    linestyle="--")
    ax.set_xticks(list(range(len(labels))))
    ax.set_xticklabels(labels, rotation=30, ha="right", fontsize=8)
    ax.tick_params(axis="x", pad=2)
    ax.axhline(0, color="#888888", linewidth=0.8)
    ax.set_xlabel(str(spec.get("x_axis_title") or "项目"))
    ax.set_ylabel(str(spec.get("y_axis_title") or "数值"))
    return True


def render_line(ax, spec, rows):
    years = [norm(r.get("year")) for r in rows]
    has_years = (len(years) >= 2 and all(y is not None for y in years)
                 and len({y for y in years}) >= 2)
    if has_years:
        by = {}
        for i, r in enumerate(rows):
            by.setdefault(series_key(r, i), []).append((norm(r.get("year")), norm(r.get("value"))))
        plotted = 0
        for ci, (name, pts) in enumerate(by.items()):
            pts = sorted(p for p in pts if p[1] is not None)
            if not pts:
                continue
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            ax.plot(xs, ys, marker="o", linewidth=2,
                    color=COLOR_BLIND_PALETTE[ci % len(COLOR_BLIND_PALETTE)], label=name)
            if len(ys) <= 12:
                for x, y in zip(xs, ys):
                    ax.text(x, y, f"{y:g}", ha="center", va="bottom", fontsize=7.5)
            plotted += 1
        if plotted > 1:
            ax.legend(fontsize=8, frameon=False)
        ax.set_xlabel(str(spec.get("x_axis_title") or "年份"))
    else:
        labels = [short_label(r) for r in rows]
        vals = [norm(r.get("value")) for r in rows]
        xs = list(range(len(vals)))
        ax.plot(xs, vals, marker="o", linewidth=2, color=COLOR_BLIND_PALETTE[0])
        ax.set_xticks(xs)
        ax.set_xticklabels(labels, rotation=25, fontsize=8)
        ax.set_xlabel(str(spec.get("x_axis_title") or "类别/年份"))
    ax.set_ylabel(str(spec.get("y_axis_title") or "数值"))
    ax.grid(alpha=0.25)
    return True


def render_pie(ax, spec, rows):
    items = [(short_label(r), norm(r.get("value"))) for r in rows]
    items = [(l, v) for l, v in items if v is not None]
    if not items or len(items) > 5:
        return False
    labels = [l for l, _ in items]
    vals = [v for _, v in items]
    total = sum(vals)
    if total <= 0:
        return False
    unit = str(spec.get("unit") or "")
    is_pct = unit == "%" or all(v <= 100 for v in vals)
    if is_pct and not (95 <= total <= 105):
        print(f"SKIP pie: 占比数据加和 {total:.1f}% 不为 100%，饼图会误导", flush=True)
        return False
    wedges, _ = ax.pie(
        vals, labels=labels, colors=COLOR_BLIND_PALETTE[:len(labels)],
        startangle=90, counterclock=False,
        wedgeprops={"edgecolor": "white", "linewidth": 1},
    )
    ax.axis("equal")
    # 数据标注：直接用原值（占比数据即原百分比，禁止重算占比导致图与数据不符）
    for w, v in zip(wedges, vals):
        ang = (w.theta2 - w.theta1) / 2.0 + w.theta1
        x = 0.70 * np.cos(np.deg2rad(ang))
        y = 0.70 * np.sin(np.deg2rad(ang))
        if is_pct:
            ax.text(x, y, f"{v:g}%", ha="center", va="center",
                    fontsize=9, color="white", weight="bold")
        else:
            share = 100.0 * v / total
            ax.text(x, y, f"{v:g}{unit}\n{share:.1f}%", ha="center", va="center",
                    fontsize=8, color="white", weight="bold")
    return True


def render_scatter(ax, spec, rows):
    xs = [norm(r.get("year")) for r in rows]
    ys = [norm(r.get("value")) for r in rows]
    if not any(x is not None and y is not None for x, y in zip(xs, ys)):
        # 无年份 → 以序号为横轴，标签做刻度
        labels = [short_label(r) for r in rows]
        xs = list(range(len(rows)))
        ax.scatter(xs, ys, s=48, color=COLOR_BLIND_PALETTE[0], edgecolor="white")
        ax.set_xticks(xs)
        ax.set_xticklabels(labels, rotation=25, fontsize=8)
        ax.set_xlabel(str(spec.get("x_axis_title") or "类别/序号"))
    else:
        ax.scatter(xs, ys, s=48, color=COLOR_BLIND_PALETTE[0], edgecolor="white")
        ax.set_xlabel(str(spec.get("x_axis_title") or "年份/序号"))
    ax.set_ylabel(str(spec.get("y_axis_title") or "数值"))
    ax.grid(alpha=0.25)
    return True


def main():
    with open("chart_data.json", encoding="utf-8") as f:
        payload = json.load(f)
    specs = payload.get("charts")
    if specs is None:
        rows = payload.get("data") or []
        specs = wrap_rows_to_specs([r for r in rows if isinstance(r, dict)])
    specs = [s for s in specs if isinstance(s, dict)]
    manifest = []
    idx = 0
    seen_specs: set = set()
    # A2：多轮渲染前清理上一轮产出的 chart_N.png，避免旧轮坏图（乱码标签）
    # 残留进入交付；语义图（financial_trends 等）不在清理范围
    for _stale in [
        f for f in os.listdir(".") if re.fullmatch(r"chart_\d+\.png", f)
    ]:
        try:
            os.remove(_stale)
        except OSError:
            pass
    for i, spec in enumerate(specs):
        issues = validate_spec(spec)
        if issues:
            print(f"SKIP chart#{i}: {'; '.join(issues)}", flush=True)
            continue
        rows = [r for r in spec.get("data") or [] if isinstance(r, dict)]
        # 数据级去重：指纹含图表类型与行全维度。scatter 的 x 轴在 caliber
        # 字段（如"涨跌幅-9.99%"），必须计入，否则"成交额柱状图"与"量价散点"
        # 因 (label,value) 相同被判重 → 用户点名的散点图被误杀（BUG-9）。
        # BUG-9 残留修复：指纹做归一化——value 取 2 位小数、label 去尾"年"、
        # unit 去空白，LLM 重发同数据时的格式微差不再逃逸
        def _norm_fp(s):
            s = str(s or "").strip()
            try:
                return f"{float(s):.2f}"
            except (TypeError, ValueError):
                return s

        _ctype = str(spec.get("type") or "bar")
        _fp = tuple(sorted(
            (_ctype, str(r.get("label") or "").strip().rstrip("年"),
             _norm_fp(r.get("value")), _norm_fp(r.get("unit")),
             str(r.get("caliber") or "").strip())
            for r in rows
        ))
        if _fp in seen_specs:
            print(f"SKIP chart#{i}: 与已渲染图表数据完全相同（{str(spec.get('title') or '')[:40]}），跳过重复图", flush=True)
            continue
        seen_specs.add(_fp)
        if idx >= 8:
            print(f"SKIP chart#{i}: 单报告图表已达上限 8 张（{str(spec.get('title') or '')[:40]}）", flush=True)
            continue
        ctype = str(spec.get("type") or "bar")
        conclusion = str(spec.get("conclusion") or "").strip()
        title = str(spec.get("title") or "").strip()
        if len(rows) < 2:
            print(f"SKIP chart#{i}: 数据点少于 2 个，单点图无结论（{title}）", flush=True)
            continue
        fig, ax = plt.subplots(figsize=(9.5, 5.6))
        fig.subplots_adjust(bottom=0.46 if ctype == "waterfall" else 0.34)
        ok = False
        if ctype == "pie":
            ok = render_pie(ax, spec, rows)
        elif ctype == "horizontal_bar":
            ok = render_bar(ax, spec, rows, horizontal=True)
        elif ctype == "grouped_bar":
            ok = render_grouped_bar(ax, spec, rows)
        elif ctype == "waterfall":
            ok = render_waterfall(ax, spec, rows)
        elif ctype == "line":
            ok = render_line(ax, spec, rows)
        elif ctype == "scatter":
            ok = render_scatter(ax, spec, rows)
        else:
            ok = render_bar(ax, spec, rows, horizontal=False)
        if not ok:
            print(f"SKIP chart#{i}: 数据无法支撑 {ctype} 图（{title}）", flush=True)
            plt.close(fig)
            continue
        ax.set_title(title or "图表", fontsize=12, pad=10)
        add_footer(fig, spec, rows, conclusion)
        idx += 1
        fname = f"chart_{idx}.png"
        # 图表视觉质量 QA + 自动修复（无视觉 LLM 的确定性替代）：
        # 标签重叠/图例遮挡/字号过小 → 自动调整并重渲染
        from chart_qa import render_with_qa
        residual = render_with_qa(fig, ax, fname, dpi=120)
        if residual:
            print(f"QA issue {fname}: {'; '.join(r['detail'] for r in residual[:3])}", flush=True)
        plt.close(fig)
        manifest.append({
            "file": fname,
            # C-2：稳定语义身份 + 绑定（指标/单位/期间/口径）——编号只是显示结果
            "chart_id": str(spec.get("chart_id") or ""),
            "binding": dict(spec.get("binding") or {}),
            "keywords": keywords_for(spec),
            "section_hint": str(spec.get("section_hint") or ""),
            # F3-B：图要回答的问题与由数据算出的观察——简报图注直接用它
            "question": str(spec.get("question") or ""),
            "observation": conclusion,
            "caption": str(spec.get("caption") or ""),
            # A6：类型与质量分级，报告生成端据此做发布级/草稿级路由
            "type": ctype,
            "grade": "draft" if residual else "publish",
            "draft_reason": (
                "；".join(str(r.get("detail") or "") for r in residual[:3])
                if residual else ""
            ),
        })
        print(f"RENDERED {fname}: {title}", flush=True)
    # 合并写入：保留既有条目（含 make_charts 语义图回填），仅更新/追加 chart_N
    try:
        with open("chart_manifest.json", "r", encoding="utf-8") as f:
            prev = json.load(f).get("charts") or []
    except Exception:
        prev = []
    prev = [c for c in prev if isinstance(c, dict)]
    # 剔除上一轮遗留的 chart_N 条目（本轮已全量重渲染，旧条目不再有效）；
    # 语义图条目（financial_trends 等，由 make_charts 回填）无条件保留
    prev = [
        c for c in prev
        if not re.fullmatch(r"chart_\d+\.png", str(c.get("file") or ""))
    ]
    prev_files = {str(c.get("file") or "") for c in prev}
    for c in manifest:
        if str(c.get("file") or "") in prev_files:
            prev = [c if str(x.get("file") or "") == str(c.get("file") or "") else x for x in prev]
        else:
            prev.append(c)
    with open("chart_manifest.json", "w", encoding="utf-8") as f:
        json.dump({"charts": prev}, f, ensure_ascii=False, indent=1)
    print(f"total={len(manifest)} skipped={len(specs) - len(manifest)}", flush=True)


if __name__ == "__main__":
    main()
